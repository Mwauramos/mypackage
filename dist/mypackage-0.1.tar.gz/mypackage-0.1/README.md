# mypackage

This library was created as an example of how to publish your own Python package.

## How to Install

You can install `mypackage` using pip. Open your terminal and run the following command:

```bash
pip install mypackage
